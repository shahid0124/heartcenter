<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>

		</div><!-- .site-content -->

		<footer id="colophon" class="site-footer" role="contentinfo">
			<?php if ( has_nav_menu( 'primary' ) ) : ?>
				<nav class="main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Footer Primary Menu', 'twentysixteen' ); ?>">
					<?php
						wp_nav_menu( array(
							'theme_location' => 'primary',
							'menu_class'     => 'primary-menu',
						 ) );
					?>
				</nav><!-- .main-navigation -->
			<?php endif; ?>

			<?php if ( has_nav_menu( 'social' ) ) : ?>
				<nav class="social-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Footer Social Links Menu', 'twentysixteen' ); ?>">
					<?php
						wp_nav_menu( array(
							'theme_location' => 'social',
							'menu_class'     => 'social-links-menu',
							'depth'          => 1,
							'link_before'    => '<span class="screen-reader-text">',
							'link_after'     => '</span>',
						) );
					?>
				</nav><!-- .social-navigation -->
			<?php endif; ?>

			<div class="site-info">
				<?php
					/**
					 * Fires before the twentysixteen footer text for footer customization.
					 *
					 * @since Twenty Sixteen 1.0
					 */
					do_action( 'twentysixteen_credits' );
				?>
				<span class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></span>
				<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'twentysixteen' ) ); ?>"><?php printf( __( 'Proudly powered by %s', 'twentysixteen' ), 'WordPress' ); ?></a>
			</div><!-- .site-info -->
		</footer><!-- .site-footer -->
	</div><!-- .site-inner -->
</div><!-- .site -->

<?php wp_footer(); ?>
</body>
</html>




<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
    
    if(isset($_POST["submit"]))
    {
        
       if (!$_POST['name'] || !$_POST['email'] || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) || !$_POST['mobileno'] || !$_POST['message'])
              
                       {
                  header('Location:contactus.php');
			
		}          
  
     else 
     {
    include('contactformsubmit.php');
     }
    }          
         
?>

    
 <footer id="footer" class="footer">

   <div class="container">  
     
         
         <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
<div class="menu_simple">
     <h4 style="color:white; text-align: left;">Services</h4>
       <ul>
<li><a href="#">IT Consulting</a></li>
<li><a href="#">Release Management</a></li>
<li><a href="#">Application Solution</a></li>
<li><a href="#">Training as a service</a></li>
<li><a href="#">Business System Platform</a></li>
<li><a href="#">ICT as a Service</a></li>
<li><a href="#">Resource Management</a></li>

</ul>
</div>
         </div>
    
     
    <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
     <div class="contactdetails">  
          <h4> Contact Details</h4> 
          <p> <strong>Head Office: </strong><br>Suite 2, Level 1, 426 church street,<br>
              Parramatta, NSW-2150</p>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3312.9744830916893!2d151.205194615781!3d-33.864548480657405!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b12ae41a06d3b9f%3A0x600415ba5b33e6c1!2sProGalore+Pty+Ltd!5e0!3m2!1sen!2sau!4v1463494466776" width="250" height="150" frameborder="0" style="border:0" allowfullscreen></iframe>
         
          <p><strong>Sydney Office: </strong> <br>
              level 8, 80 Clarence st 
              Sydney s NSW-2000
          
          </p>
          
        <p>Tel: +61-02-9683 4200</p>
         
      
       
             </div>
      </div>
      
           <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
               <h4 style="color:white"> Send your enquiry </h4>
           <div class="footerformwrap">
     
         <div class="row">
             <form class="form-horizontal" role="form" method="post" action="contactus.php">
                 <div class="form-group">
                     <label for="name" class="col-xs-2 col-sm-2 col-xs-offset-1 control-label">Name</label>
                     <div class="col-xs-8 col-sm-9">
                         <input type="text" class="form-control" id="name" name="name" placeholder="Full Name" value="<?php echo htmlspecialchars($_POST['name']); ?>">
                    
                     </div>
                 </div>
               <div class="form-group">
                  <label for="email" class="col-xs-2 col-sm-2 col-xs-offset-1 control-label">Email</label>
                  <div class="col-xs-8 col-sm-9">
                     <input type="email" class="form-control" id="email" name="email" placeholder="example@domain.com" value="<?php echo htmlspecialchars($_POST['name']); ?>">
                      			
                  </div>
               </div>
            <div class="form-group">
                  <label for="MobileNo" class="col-xs-2 col-sm-2 col-xs-offset-1 control-label">Phone</label>
                  <div class="col-xs-8 col-sm-9">
                     <input type="text" class="form-control" id="mobileno" name="mobileno" placeholder="Phone No:" value="<?php echo htmlspecialchars($_POST['name']); ?>">
                        
                  </div>
               </div>
              <div class="form-group">
                  <label for="message" class="col-xs-2 col-sm-2 col-xs-offset-1 control-label">Message</label>
                  <div class="col-xs-8 col-sm-9">
                      <textarea class="form-control" rows="4" name="message" placeholder="Message"></textarea>
                      
                  </div>
              </div>
            <div class="form-group">
                <div class="col-xs-5 col-sm-3 col-sm-offset-4 col-xs-offset-4">
                    <input id="submit" name="submit" type="submit" value="submit" class="btn btn-primary">
                </div>
                
            </div>
                 
           
             </form>
         
     </div>
 </div>
       </div>
   </div>
</footer>
<div class="copyright">
    <p> COPYRIGHT&#169-All Rights Reserved - 2009 ProGalore Institute for Technology & Management</p>
</div>
  