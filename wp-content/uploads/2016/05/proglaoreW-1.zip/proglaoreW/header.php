<?php
/*
Theme Name: Progalore
Theme URI:http://localhost/progalore/
Description: Progalore Australia Consulting Services
Version: 1.0
Author:Shahid Javed

*/
?>
<html>
<head>
	    <meta charset="<?php bloginfo( 'charset' ); ?>">
	    <meta name="viewport" content="width=device-width">
	    <title><?php wp_title( '|', true, 'right' ); ?></title>
	    <link rel="profile" href="http://gmpg.org/xfn/11">
	    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	    <!--&#91;if lt IE 9&#93;>
	    <script src="<?php echo get_template_directory_uri(); ?>/js/html5.js"></script>
	    <!&#91;endif&#93;-->
	    <?php wp_head(); ?>
	    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" />
	</head>
<body>
<div class="headerdiv" id="headerdiv">
    <div class="container-fluid">
  <header class="page-header">
      <div class="row-fluid">
          
      <div class="phonedetails">
          <div class="col-xs-12 col-sm-12 col-md-12">
    <img src="img/phone.jpg" class="phoneimage"  alt="Phone #">
    <a href="#" class="contactusphoneNo">:02 9683 4200</a>
      </div>
      <div class="emaildetails"> 
     <img src="img/email.png" class="emailimage"  alt="Phone #">
     <a href="mailto:info@progalorehub.com.au" class="contactusemail">:info@progalorehub.com.au</a>
      </div>
      </div>
    </div>
  
</div>
</div>
<div class="container-fluid">
<div class="mainnavigation" >              
<nav id="navbar-main">
  
    <div class="row-fluid">  
      <div class="brandelements">
         <div class="col-sm-12 col-md-12 col-lg-12">
      <a class="navbar-brand" href="#"><img src="img/logo.jpg" class="logoimage" alt="Porgalore Consulting Services"></a>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <h1 class="mainheading">Australia Consulting Services</h1>
         </div>
      </div>
<div id="navbar" class="collapse navbar-collapse">
<div class="navigation">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="aboutus.php">About US</a></li>
        <li><a href="services.php">Services</a></li>
         <li><a href="ourclients.php">Our clients</a></li>
          <li><a href="contactus.php">Contact Us</a></li>
      </ul>
</div>
</div>      
    <!--/.nav-collapse -->
    
 <form class="navbar-form navbar-right" role="search">
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Search">
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>   
  </div> 
    </div>
</nav>
    </div>
</header> 
