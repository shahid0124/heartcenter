<?php
/*
Theme Name: Progalore
Theme URI:http://localhost/progalore/
Description: Progalore Australia Consulting Services
Version: 1.0
Author:Shahid Javed

*/
?>